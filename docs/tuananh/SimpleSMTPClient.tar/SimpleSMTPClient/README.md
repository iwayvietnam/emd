# Simple SMTP Client

## A simple and to the point SMTP test client

1. Download the release under the "release" tab.
2. Supports Basic Authentication to SMTP server.
3. Supports Anonymous connection to SMTP Server.
4. Supports SSL connection to SMTP server in STARTSSL mode only. Does not support connecting to SMTP/SSL, SMTP over SSL, or SMTPS server on default port 465.
5. Runs on Windows.

![Image of Software](https://i.imgur.com/Z7NCEcm.png)
